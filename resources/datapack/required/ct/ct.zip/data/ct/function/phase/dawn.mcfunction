execute as @a run fmvariable set phase false 1
scoreboard players set phase game_data 1
execute as @a run attribute @s[tag=!storyteller,tag=!spectator] minecraft:movement_speed modifier add ct:travel_speed 0.4 add_multiplied_base
time set 23500
execute as @e[type=minecraft:item_display,tag=house] run data modify entity @s view_range set value 0
execute as @e[type=minecraft:item_display,tag=exclamation_yellow] run data modify entity @s view_range set value 1

execute as @a at @s run playsound ct:clocktower.enable_sounds
execute as @a at @s run playsound ct:clocktower.bell voice @s ~ ~ ~ 1 1.2

tellraw @a [{"text":"⌚ ","color":"yellow"},{"text":"The sun has risen! Please return to the town square.","color":"gray"}]

execute if score phase_causes_tp settings matches 1 run function ct:cmd/tpseats

team modify 99_storyteller nametagVisibility always
team modify 01_red nametagVisibility always
team modify 02_orange nametagVisibility always
team modify 03_yellow nametagVisibility always
team modify 04_lime nametagVisibility always
team modify 05_green nametagVisibility always
team modify 06_mint nametagVisibility always
team modify 07_cyan nametagVisibility always
team modify 08_blue nametagVisibility always
team modify 09_navy nametagVisibility always
team modify 10_purple nametagVisibility always
team modify 11_magenta nametagVisibility always
team modify 12_lavender nametagVisibility always
team modify 13_white nametagVisibility always
team modify 14_gray nametagVisibility always
team modify 15_black nametagVisibility always
team modify 00_spectator nametagVisibility always

tag @a remove universal_vc
execute as @a run voicechat leave

clear @a minecraft:compass[minecraft:custom_name={italic:0b,text:"Home Compass"}]

function ct:util/sync_variables