execute as @a if score @s id = @s vc run tag @s add in_house
clear @a[tag=in_house] minecraft:compass
tag @a remove in_house

execute if entity @a[tag=!storyteller,tag=!spectator,scores={vc=0}] run title @a[tag=storyteller] actionbar [{"selector": "@a[tag=!storyteller,tag=!spectator,scores={vc=0}]"},{"text":" is not in a house.","color":"red"}]
# execute unless entity @a[tag=!storyteller,tag=!spectator] unless entity @a[tag=requesting_chat] run title @a[tag=storyteller] actionbar [{"text":"All players are in a house.","color":"green"}]
execute store result score growl game_data run random value 0..3000
execute if score growl game_data matches 1 if score current_day game_data matches 2.. as @r[tag=!storyteller,tag=!spectator] at @s run playsound ct:clocktower.night.ambient voice @a ~ ~ ~10

execute as @a[scores={reveal_cd=139},tag=!spectator,tag=!storyteller] if score @s vc = @s id run function ct:start_game/roles/youare
execute as @a[tag=!spectator,tag=!storyteller,scores={reveal_cd=1..}] if score @s vc = @s id run scoreboard players remove @s reveal_cd 1
execute as @a[scores={reveal_cd=60}] run function ct:start_game/roles/announce
tellraw @s[tag=!storyteller,tag=!spectator,scores={reveal_cd=1}] [{"translate":"clocktower.prefix.generic","color":"yellow","bold":true},{"translate":"clocktower.notice.hover_hint","color":"gray","bold":false, "with":[{"keybind":"key.chat"}]}]
execute as @a at @s run function ct:loop/player/night
function ct:util/timer/end

## Window/Door Particles
# Red
particle minecraft:dust{scale:4,color:0} 80.81 77.91 109 0 0.5 0.6 1 3 normal @a[scores={vc=1},team=01_red]
particle minecraft:dust{scale:4,color:0} 83.50 78.94 116.56 0.5 0.5 0 1 1 normal @a[scores={vc=1},team=01_red]

# Orange
particle minecraft:dust{scale:4,color:0} 68.51 77.00 124.00 0.3 0.5 0 1 3 normal @a[scores={vc=2},team=02_orange]

# Yellow
particle minecraft:dust{scale:4,color:0} 55.19 77.00 111.48 0 0.5 0.3 1 3 normal @a[scores={vc=3},team=03_yellow]
particle minecraft:dust{scale:4,color:0} 55.19 83.00 111.48 0 0.5 0.3 1 3 normal @a[scores={vc=3},team=03_yellow]
particle minecraft:dust{scale:4,color:0} 49.48 78.00 121.19 0.3 0.5 0 1 3 normal @a[scores={vc=3},team=03_yellow]
particle minecraft:dust{scale:4,color:0} 53.53 78.00 113.63 0.3 0.5 0 1 1 normal @a[scores={vc=3},team=03_yellow]
particle minecraft:dust{scale:4,color:0} 53.50 78.00 109.38 0.3 0.5 0 1 1 normal @a[scores={vc=3},team=03_yellow]

# Lime
particle minecraft:dust{scale:4,color:0} 98.00 85.01 27.19 0.6 0.5 0 1 3 normal @a[scores={vc=4},team=04_lime]
particle minecraft:dust{scale:4,color:0} 100.56 86.01 23.52 0 0.5 1 1 5 normal @a[scores={vc=4},team=04_lime]

# Green
particle minecraft:dust{scale:4,color:0} 111.01 82.00 15.19 0.6 0.5 0 1 3 normal @a[scores={vc=5},team=05_green]
particle minecraft:dust{scale:4,color:0} 106.99 82 16.00 0.6 0.5 0 1 3 normal @a[scores={vc=5},team=05_green]

# Mint
particle minecraft:dust{scale:4,color:0} 124.48 81.00 13.00 0.3 0.5 0 1 3 normal @a[scores={vc=6},team=06_mint]
particle minecraft:dust{scale:4,color:0} 121.51 82.00 13.56 0.3 0.5 0 1 3 normal @a[scores={vc=6},team=06_mint]
particle minecraft:dust{scale:4,color:0} 127.52 82.00 13.56 0.3 0.5 0 1 3 normal @a[scores={vc=6},team=06_mint]

# Cyan
particle minecraft:dust{scale:4,color:0} 141.00 80.00 16.50 0 0.5 0.3 1 3 normal @a[scores={vc=7},team=07_cyan]
particle minecraft:dust{scale:4,color:0} 145.52 80.99 20.19 0.3 0.5 0 1 3 normal @a[scores={vc=7},team=07_cyan]

# Blue
particle minecraft:dust{scale:4,color:0} 165.49 73.00 37.19 0.3 0.5 0 1 3 normal @a[scores={vc=8},team=08_blue]
particle minecraft:dust{scale:4,color:0} 165.50 76 37.44 0.3 0.5 0.3 1 1 normal @a[scores={vc=8},team=08_blue]

# Navy
particle minecraft:dust{scale:4,color:0} 179.47 74.00 47.19 0.3 0.5 0 1 3 normal @a[scores={vc=9},team=09_navy]
particle minecraft:dust{scale:4,color:0} 175.50 75.51 44.55 0 0.5 0.3 1 3 normal @a[scores={vc=9},team=09_navy]
particle minecraft:dust{scale:4,color:0} 181.50 75.51 44.45 0 0.5 0.3 1 3 normal @a[scores={vc=9},team=09_navy]

# Purple
particle minecraft:dust{scale:4,color:0} 182.81 72.00 63.48 0 0.5 0.3 1 3 normal @a[scores={vc=10},team=10_purple]
particle minecraft:dust{scale:4,color:0} 182.50 73.00 59.47 0 0.5 0.3 1 3 normal @a[scores={vc=10},team=10_purple]
particle minecraft:dust{scale:4,color:0} 182.50 76.00 63.49 0 0.5 0.3 1 3 normal @a[scores={vc=10},team=10_purple]

# Magenta
particle minecraft:dust{scale:4,color:0} 152.50 72.00 85.19 0.3 0.5 0 1 3 normal @a[scores={vc=11},team=11_magenta]
particle minecraft:dust{scale:4,color:0} 157.48 72.65 84.50 0.3 0.5 0 1 2 normal @a[scores={vc=11},team=11_magenta]
particle minecraft:dust{scale:4,color:0} 149.50 72.60 82.63 0 0.5 0.3 1 2 normal @a[scores={vc=11},team=11_magenta]
particle minecraft:dust{scale:4,color:0} 152.48 75.12 85.60 0 0.5 0.3 1 2 normal @a[scores={vc=11},team=11_magenta]

# Lavender
particle minecraft:dust{scale:4,color:0} 170.00 72.01 89.19 1 0.5 0 1 5 normal @a[scores={vc=12},team=12_lavender]
particle minecraft:dust{scale:4,color:0} 167.51 72.66 89.5 0.3 0.5 0 1 3 normal @a[scores={vc=12},team=12_lavender]
particle minecraft:dust{scale:4,color:0} 172.51 72.66 89.5 0.3 0.5 0 1 3 normal @a[scores={vc=12},team=12_lavender]

# White
particle minecraft:dust{scale:4,color:0} 179.81 73.01 97.50 0 0.5 0.3 1 3 normal @a[scores={vc=13},team=13_white]
particle minecraft:dust{scale:4,color:0} 182.44 73.50 101.50 0 0.5 0.3 1 1 normal @a[scores={vc=13},team=13_white]
particle minecraft:dust{scale:4,color:0} 184.53 73.65 103.50 0 0.5 0.3 1 2 normal @a[scores={vc=13},team=13_white]

# Gray
particle minecraft:dust{scale:4,color:0} 170.51 73.00 106.81 0.3 0.5 0 1 3 normal @a[scores={vc=14},team=14_gray]
particle minecraft:dust{scale:4,color:0} 166.52 73.65 107.50 0.3 0.5 0 1 2 normal @a[scores={vc=14},team=14_gray]
particle minecraft:dust{scale:4,color:0} 164.44 73.51 109.48 0 0.5 0.3 1 3 normal @a[scores={vc=14},team=14_gray]
particle minecraft:dust{scale:4,color:0} 164.44 73.51 111.48 0 0.5 0.3 1 3 normal @a[scores={vc=14},team=14_gray]
particle minecraft:dust{scale:4,color:0} 170.52 76.50 106.49 0.3 0.5 0 1 3 normal @a[scores={vc=14},team=14_gray]

# Black
particle minecraft:dust{scale:4,color:0} 151.49 73.99 112.81 0.3 0.5 0 1 3 normal @a[scores={vc=15},team=15_black]
particle minecraft:dust{scale:4,color:0} 156.49 74.59 113.50 0.3 0.5 0 1 2 normal @a[scores={vc=15},team=15_black]