scoreboard players set dev_mode game_data 0
scoreboard players set has_initialized game_data 0
team leave @s
fmvariable set storyteller false false
fmvariable set closed_warning false false
fmvariable set dev false false
fmvariable get version
tag @s remove storyteller
clear @s minecraft:carrot_on_a_stick[minecraft:custom_model_data={strings:["ct_bag"]}]
clear @s minecraft:carrot_on_a_stick[minecraft:custom_model_data={strings:["start_vote"]}]
gamerule send_command_feedback false
gamerule reduced_debug_info true
gamerule spectators_generate_chunks false
tp @s 121.49 72.00 71.59 -502.90 1.65